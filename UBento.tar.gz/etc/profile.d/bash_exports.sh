## /etc/profile.d/bash_exports.sh

## Begin /etc/profile.d/bash_exports.sh

## Desktop defaults (if not set yet)
if [ -z "$DESKTOP_SESSION" ]; then
    export DESKTOP_SESSION="ubuntu"
fi

if [ -z "$GNOME_SHELL_SESSION_MODE" ]; then
    export GNOME_SHELL_SESSION_MODE="ubuntu"
fi

## Ubuntu default desktop (GNOME Shell variant)
if [ -z "$XDG_CURRENT_DESKTOP" ]; then
    export XDG_CURRENT_DESKTOP="ubuntu:GNOME"
fi

if [ -z "$XDG_SESSION_DESKTOP" ]; then
    export XDG_SESSION_DESKTOP="ubuntu"
fi

if [ -z "$XDG_MENU_PREFIX" ]; then
    export XDG_MENU_PREFIX="gnome-"
fi

if [ -z "$XDG_SESSION_TYPE" ]; then
    export XDG_SESSION_TYPE="x11"
fi

if [ -z "$XDG_SESSION_CLASS" ]; then
    export XDG_SESSION_CLASS="user"
fi

## End /etc/profile.d/bash_exports.sh
