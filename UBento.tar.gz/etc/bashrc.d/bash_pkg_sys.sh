# Begin ~/bash_pkg.sh

# System vars
export DISTRO="$(lsb_release -cs)"
export ARCH="$(dpkg --print-architecture)"
export APT_SOURCES="/etc/apt/sources.list.d"

# End ~/bash_pkg.sh
